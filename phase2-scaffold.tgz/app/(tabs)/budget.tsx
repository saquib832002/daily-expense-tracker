import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  getBaseCurrency,
  getFirstDayOfMonth,
  getMonthlyBudget,
  setMonthlyBudget,
  spentInPeriod,
} from '@/db/queries';
import { computePace, monthBounds, type BudgetPace } from '@/domain/budget';
import { formatMinor, minorToDecimalString, parseAmountToMinor } from '@/domain/money';
import { t } from '@/i18n';
import { radius, space, type, useTheme } from '@/theme';

/** Phase 1: the overall monthly budget. Per-category budgets land in Phase 3. */
export default function BudgetScreen() {
  const theme = useTheme();
  const [currency, setCurrency] = useState('INR');
  const [draft, setDraft] = useState('');
  const [pace, setPace] = useState<BudgetPace | null>(null);

  const load = useCallback(async () => {
    const base = await getBaseCurrency();
    const firstDay = await getFirstDayOfMonth();
    const bounds = monthBounds(Date.now(), firstDay);
    const limit = await getMonthlyBudget();
    const spent = await spentInPeriod(bounds.start, bounds.end);

    setCurrency(base);
    setDraft(limit != null ? minorToDecimalString(limit, base) : '');
    setPace(limit != null ? computePace(spent, limit, Date.now(), bounds) : null);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  const save = useCallback(async () => {
    const minor = parseAmountToMinor(draft, currency);
    if (minor == null || minor <= 0) return;
    await setMonthlyBudget(minor, currency);
    await load();
  }, [draft, currency, load]);

  const statusColor =
    pace?.status === 'over' ? theme.danger : pace?.status === 'warn' ? theme.warn : theme.accent;

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.bg }]} edges={['top']}>
      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.text }]}>{t('budget.title')}</Text>

        <View style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <Text style={[styles.label, { color: theme.textDim }]}>{t('budget.monthly')}</Text>

          <View style={styles.inputRow}>
            <TextInput
              value={draft}
              onChangeText={setDraft}
              keyboardType="decimal-pad"
              placeholder="0"
              placeholderTextColor={theme.textDim}
              style={[
                styles.input,
                { color: theme.text, borderColor: theme.border, backgroundColor: theme.bg },
              ]}
            />
            <Pressable
              onPress={save}
              style={({ pressed }) => [
                styles.button,
                { backgroundColor: pressed ? theme.accentSoft : theme.accent },
              ]}
            >
              <Text style={{ color: theme.onAccent, fontWeight: '600' }}>{t('budget.set')}</Text>
            </Pressable>
          </View>

          {pace ? (
            <>
              <View style={[styles.track, { backgroundColor: theme.surfaceAlt }]}>
                <View
                  style={[
                    styles.fill,
                    {
                      backgroundColor: statusColor,
                      width: `${Math.min(100, Math.max(0, pace.fractionSpent * 100))}%`,
                    },
                  ]}
                />
              </View>

              <Text style={[styles.meta, { color: theme.text }]}>
                {t('budget.spent', {
                  spent: formatMinor(pace.spentMinor, currency, { compact: true }),
                  limit: formatMinor(pace.limitMinor, currency, { compact: true }),
                })}
              </Text>

              <Text style={[styles.meta, { color: statusColor }]}>
                {pace.remainingMinor >= 0
                  ? t('budget.remaining', {
                      amount: formatMinor(pace.remainingMinor, currency, { compact: true }),
                    })
                  : t('budget.over', {
                      amount: formatMinor(Math.abs(pace.remainingMinor), currency, { compact: true }),
                    })}
              </Text>

              <Text style={[styles.pace, { color: theme.textDim }]}>
                {t('budget.pace', {
                  elapsed: Math.round(pace.fractionElapsed * 100),
                  spent: Math.round(pace.fractionSpent * 100),
                })}
              </Text>
            </>
          ) : (
            <Text style={[styles.meta, { color: theme.textDim }]}>{t('budget.none')}</Text>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { padding: space.lg, gap: space.lg },
  title: { fontSize: type.title, fontWeight: '600' },
  card: { borderRadius: radius.lg, borderWidth: 1, padding: space.lg, gap: space.md },
  label: { fontSize: type.tiny, textTransform: 'uppercase', letterSpacing: 1 },
  inputRow: { flexDirection: 'row', gap: space.sm, alignItems: 'center' },
  input: {
    flex: 1,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: space.md,
    paddingVertical: space.md,
    fontSize: type.title,
    fontVariant: ['tabular-nums'],
  },
  button: {
    paddingHorizontal: space.lg,
    paddingVertical: space.md + 2,
    borderRadius: radius.md,
  },
  track: { height: 10, borderRadius: radius.pill, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: radius.pill },
  meta: { fontSize: type.body },
  pace: { fontSize: type.small },
});

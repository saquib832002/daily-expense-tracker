import { and, desc, eq, gte, isNull, lt, ne, sql } from 'drizzle-orm';
import { randomUUID } from 'expo-crypto';

import { normalizeMerchant } from '@/domain/merchant';

import { db } from './client';
import {
  accounts,
  budgets,
  categories,
  merchantMemory,
  outbox,
  settings,
  transactions,
  type Account,
  type Category,
  type Transaction,
} from './schema';

/* ------------------------------------------------------------------- outbox */

/**
 * Record a local change so the sync layer can replay it later.
 * Sync itself lands in v1.1 — writing the outbox now costs nothing and means
 * switching sync on is additive rather than a migration.
 */
async function trackChange(table: string, rowId: string, op: 'insert' | 'update' | 'delete') {
  await db.insert(outbox).values({ tableName: table, rowId, op, at: Date.now() });
}

/* ----------------------------------------------------------------- settings */

export async function getSetting(key: string): Promise<string | null> {
  const rows = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return rows[0]?.value ?? null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db
    .insert(settings)
    .values({ key, value, updatedAt: Date.now() })
    .onConflictDoUpdate({
      target: settings.key,
      set: { value, updatedAt: Date.now() },
    });
}

export async function getBaseCurrency(): Promise<string> {
  return (await getSetting('base_currency')) ?? 'INR';
}

export async function getFirstDayOfMonth(): Promise<number> {
  const raw = await getSetting('first_day_of_month');
  const n = Number(raw ?? 1);
  return Number.isFinite(n) ? n : 1;
}

/* ---------------------------------------------------------------- accounts */

export async function listAccounts(includeArchived = false): Promise<Account[]> {
  const where = includeArchived
    ? isNull(accounts.deletedAt)
    : and(isNull(accounts.deletedAt), eq(accounts.isArchived, 0));
  return db.select().from(accounts).where(where).orderBy(accounts.sortOrder);
}

export async function getAccount(id: string): Promise<Account | null> {
  const rows = await db.select().from(accounts).where(eq(accounts.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createAccount(input: {
  name: string;
  type: string;
  currency: string;
  openingBalanceMinor?: number;
  icon?: string;
}): Promise<string> {
  const now = Date.now();
  const id = randomUUID();
  const existing = await listAccounts(true);

  await db.insert(accounts).values({
    id,
    name: input.name.trim(),
    type: input.type,
    currency: input.currency,
    openingBalanceMinor: input.openingBalanceMinor ?? 0,
    icon: input.icon ?? '💳',
    sortOrder: existing.length,
    createdAt: now,
    updatedAt: now,
  });
  await trackChange('accounts', id, 'insert');
  return id;
}

export async function updateAccount(
  id: string,
  patch: Partial<Pick<Account, 'name' | 'type' | 'icon' | 'openingBalanceMinor' | 'isArchived'>>,
): Promise<void> {
  await db
    .update(accounts)
    .set({ ...patch, updatedAt: Date.now(), dirty: 1 })
    .where(eq(accounts.id, id));
  await trackChange('accounts', id, 'update');
}

/**
 * Current balance per account: opening balance plus every signed transaction.
 * One query rather than one per account, because this feeds a list.
 */
export async function accountBalances(): Promise<Record<string, number>> {
  const rows = await db
    .select({
      accountId: transactions.accountId,
      total: sql<number>`COALESCE(SUM(${transactions.amountMinor}), 0)`,
    })
    .from(transactions)
    .where(and(isNull(transactions.deletedAt), eq(transactions.status, 'confirmed')))
    .groupBy(transactions.accountId);

  const sums = new Map(rows.map((r) => [r.accountId, r.total]));
  const out: Record<string, number> = {};
  for (const a of await listAccounts(true)) {
    out[a.id] = a.openingBalanceMinor + (sums.get(a.id) ?? 0);
  }
  return out;
}

/* -------------------------------------------------------------- categories */

export async function listCategories(kind: 'expense' | 'income' = 'expense'): Promise<Category[]> {
  return db
    .select()
    .from(categories)
    .where(and(isNull(categories.deletedAt), eq(categories.kind, kind)))
    .orderBy(categories.sortOrder);
}

export async function getCategory(id: string | null): Promise<Category | null> {
  if (!id) return null;
  const rows = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createCategory(input: {
  name: string;
  kind: 'expense' | 'income';
  icon?: string;
  color?: string;
}): Promise<string> {
  const now = Date.now();
  const id = randomUUID();
  const siblings = await listCategories(input.kind);

  await db.insert(categories).values({
    id,
    customName: input.name.trim(),
    nameKey: null,
    icon: input.icon ?? '🏷️',
    color: input.color ?? '#8A8F98',
    kind: input.kind,
    isSystem: 0,
    sortOrder: siblings.length,
    createdAt: now,
    updatedAt: now,
  });
  await trackChange('categories', id, 'insert');
  return id;
}

export async function updateCategory(
  id: string,
  patch: Partial<Pick<Category, 'customName' | 'icon' | 'color'>>,
): Promise<void> {
  await db
    .update(categories)
    .set({ ...patch, updatedAt: Date.now(), dirty: 1 })
    .where(eq(categories.id, id));
  await trackChange('categories', id, 'update');
}

/**
 * Hide a category. Transactions already filed under it keep pointing at it, so
 * history never develops holes — this only removes it from the pickers.
 */
export async function hideCategory(id: string): Promise<void> {
  const now = Date.now();
  await db
    .update(categories)
    .set({ deletedAt: now, updatedAt: now, dirty: 1 })
    .where(eq(categories.id, id));
  await trackChange('categories', id, 'delete');
}

/* ------------------------------------------------------------- transactions */

export interface NewExpenseInput {
  amountMinor: number;
  accountId: string;
  categoryId?: string | null;
  merchant?: string | null;
  note?: string | null;
  occurredAt?: number;
  kind?: 'expense' | 'income';
  currency: string;
  /** Rate from the account's currency to the base currency. 1 when the same. */
  fxRate?: number;
  source?: string;
  categorySource?: string;
}

/**
 * Record a transaction.
 *
 * Amounts are stored SIGNED: expenses negative, income positive. Reports then
 * never have to know which way round a `kind` string points, and a sum is just
 * a sum.
 */
export async function addTransaction(input: NewExpenseInput): Promise<string> {
  const now = Date.now();
  const id = randomUUID();
  const kind = input.kind ?? 'expense';
  const magnitude = Math.abs(input.amountMinor);
  const signed = kind === 'income' ? magnitude : -magnitude;
  const fxRate = input.fxRate ?? 1;
  const merchantKey = normalizeMerchant(input.merchant) || null;

  await db.insert(transactions).values({
    id,
    accountId: input.accountId,
    categoryId: input.categoryId ?? null,
    amountMinor: signed,
    currency: input.currency,
    baseAmountMinor: Math.round(signed * fxRate),
    fxRate,
    kind,
    occurredAt: input.occurredAt ?? now,
    merchant: input.merchant?.trim() || null,
    merchantKey,
    note: input.note?.trim() || null,
    source: input.source ?? 'manual',
    categorySource: input.categorySource ?? 'user',
    status: 'confirmed',
    createdAt: now,
    updatedAt: now,
  });

  await trackChange('transactions', id, 'insert');

  // Teach the app: this merchant means this category. Free, instant, and the
  // reason we need no AI to categorize.
  if (merchantKey && input.categoryId) {
    await rememberMerchant(merchantKey, input.categoryId);
  }

  return id;
}

export async function getTransaction(id: string): Promise<Transaction | null> {
  const rows = await db.select().from(transactions).where(eq(transactions.id, id)).limit(1);
  return rows[0] ?? null;
}

export interface TransactionPatch {
  amountMinor?: number;
  accountId?: string;
  categoryId?: string | null;
  merchant?: string | null;
  note?: string | null;
  occurredAt?: number;
  kind?: 'expense' | 'income';
  currency?: string;
  fxRate?: number;
}

/**
 * Edit a transaction. The sign, the base amount and the merchant key are all
 * derived here rather than by the caller, so an edit can never leave a row in
 * a state that `addTransaction` would not have produced.
 */
export async function updateTransaction(id: string, patch: TransactionPatch): Promise<void> {
  const current = await getTransaction(id);
  if (!current) return;

  const kind = patch.kind ?? (current.kind as 'expense' | 'income');
  const magnitude = Math.abs(patch.amountMinor ?? current.amountMinor);
  const signed = kind === 'income' ? magnitude : -magnitude;
  const fxRate = patch.fxRate ?? current.fxRate;
  const merchant =
    patch.merchant !== undefined ? patch.merchant?.trim() || null : current.merchant;
  const merchantKey = normalizeMerchant(merchant) || null;
  const categoryId = patch.categoryId !== undefined ? patch.categoryId : current.categoryId;

  await db
    .update(transactions)
    .set({
      amountMinor: signed,
      accountId: patch.accountId ?? current.accountId,
      categoryId,
      merchant,
      merchantKey,
      note: patch.note !== undefined ? patch.note?.trim() || null : current.note,
      occurredAt: patch.occurredAt ?? current.occurredAt,
      kind,
      currency: patch.currency ?? current.currency,
      baseAmountMinor: Math.round(signed * fxRate),
      fxRate,
      categorySource: patch.categoryId !== undefined ? 'user' : current.categorySource,
      updatedAt: Date.now(),
      dirty: 1,
    })
    .where(eq(transactions.id, id));

  await trackChange('transactions', id, 'update');

  if (merchantKey && categoryId) {
    await rememberMerchant(merchantKey, categoryId);
  }
}

export async function softDeleteTransaction(id: string): Promise<void> {
  const now = Date.now();
  await db
    .update(transactions)
    .set({ deletedAt: now, updatedAt: now, dirty: 1 })
    .where(eq(transactions.id, id));
  await trackChange('transactions', id, 'delete');
}

/** Undo a delete. Nothing is ever hard-deleted, so this is always possible. */
export async function restoreTransaction(id: string): Promise<void> {
  await db
    .update(transactions)
    .set({ deletedAt: null, updatedAt: Date.now(), dirty: 1 })
    .where(eq(transactions.id, id));
  await trackChange('transactions', id, 'update');
}

export async function listTransactions(fromMs: number, toMs: number): Promise<Transaction[]> {
  return db
    .select()
    .from(transactions)
    .where(
      and(
        isNull(transactions.deletedAt),
        eq(transactions.status, 'confirmed'),
        gte(transactions.occurredAt, fromMs),
        lt(transactions.occurredAt, toMs),
      ),
    )
    .orderBy(desc(transactions.occurredAt));
}

export async function listRecent(limit = 5): Promise<Transaction[]> {
  return db
    .select()
    .from(transactions)
    .where(and(isNull(transactions.deletedAt), eq(transactions.status, 'confirmed')))
    .orderBy(desc(transactions.occurredAt))
    .limit(limit);
}

/** Total spent (a positive number) in the base currency for a period. */
export async function spentInPeriod(fromMs: number, toMs: number): Promise<number> {
  const rows = await db
    .select({
      total: sql<number>`COALESCE(SUM(${transactions.baseAmountMinor}), 0)`,
    })
    .from(transactions)
    .where(
      and(
        isNull(transactions.deletedAt),
        eq(transactions.status, 'confirmed'),
        eq(transactions.kind, 'expense'),
        gte(transactions.occurredAt, fromMs),
        lt(transactions.occurredAt, toMs),
      ),
    );
  return Math.abs(rows[0]?.total ?? 0);
}

/* ---------------------------------------------------------- merchant memory */

export interface RecentMerchant {
  merchant: string;
  merchantKey: string;
  categoryId: string | null;
  amountMinor: number;
  accountId: string;
}

/**
 * The handful of things you buy most often, newest first, one per merchant.
 *
 * This powers the one-tap chips on the add screen — the single biggest
 * reduction in typing available, because most people's spending is the same
 * six or seven places over and over.
 */
export async function recentMerchants(limit = 6): Promise<RecentMerchant[]> {
  const rows = await db
    .select({
      merchant: transactions.merchant,
      merchantKey: transactions.merchantKey,
      categoryId: transactions.categoryId,
      amountMinor: transactions.amountMinor,
      accountId: transactions.accountId,
      occurredAt: transactions.occurredAt,
    })
    .from(transactions)
    .where(
      and(
        isNull(transactions.deletedAt),
        eq(transactions.status, 'confirmed'),
        eq(transactions.kind, 'expense'),
        ne(transactions.merchantKey, ''),
      ),
    )
    .orderBy(desc(transactions.occurredAt))
    .limit(200);

  const seen = new Set<string>();
  const out: RecentMerchant[] = [];
  for (const r of rows) {
    if (!r.merchantKey || !r.merchant || seen.has(r.merchantKey)) continue;
    seen.add(r.merchantKey);
    out.push({
      merchant: r.merchant,
      merchantKey: r.merchantKey,
      categoryId: r.categoryId,
      amountMinor: Math.abs(r.amountMinor),
      accountId: r.accountId,
    });
    if (out.length >= limit) break;
  }
  return out;
}

export async function rememberMerchant(merchantKey: string, categoryId: string): Promise<void> {
  await db
    .insert(merchantMemory)
    .values({ merchantKey, categoryId, hitCount: 1, lastUsedAt: Date.now() })
    .onConflictDoUpdate({
      target: merchantMemory.merchantKey,
      set: {
        categoryId,
        hitCount: sql`${merchantMemory.hitCount} + 1`,
        lastUsedAt: Date.now(),
      },
    });
}

/** The category this merchant usually belongs to, if we have seen it before. */
export async function recallMerchant(merchantRaw: string): Promise<string | null> {
  const key = normalizeMerchant(merchantRaw);
  if (!key) return null;
  const rows = await db
    .select()
    .from(merchantMemory)
    .where(eq(merchantMemory.merchantKey, key))
    .limit(1);
  return rows[0]?.categoryId ?? null;
}

/* ------------------------------------------------------------------ budgets */

/** The overall monthly budget, or null when none is set. */
export async function getMonthlyBudget(): Promise<number | null> {
  const rows = await db
    .select()
    .from(budgets)
    .where(and(isNull(budgets.deletedAt), isNull(budgets.categoryId), eq(budgets.period, 'monthly')))
    .limit(1);
  return rows[0]?.amountMinor ?? null;
}

export async function setMonthlyBudget(amountMinor: number, currency: string): Promise<void> {
  const now = Date.now();
  const existing = await db
    .select()
    .from(budgets)
    .where(and(isNull(budgets.deletedAt), isNull(budgets.categoryId), eq(budgets.period, 'monthly')))
    .limit(1);

  const row = existing[0];
  if (row) {
    await db
      .update(budgets)
      .set({ amountMinor, currency, updatedAt: now, dirty: 1 })
      .where(eq(budgets.id, row.id));
    await trackChange('budgets', row.id, 'update');
    return;
  }

  const id = randomUUID();
  await db.insert(budgets).values({
    id,
    categoryId: null,
    period: 'monthly',
    amountMinor,
    currency,
    startsOn: now,
    createdAt: now,
    updatedAt: now,
  });
  await trackChange('budgets', id, 'insert');
}

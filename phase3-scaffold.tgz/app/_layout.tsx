import { useMigrations } from 'drizzle-orm/expo-sqlite/migrator';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import migrations from '../drizzle/migrations';
import { db } from '@/db/client';
import { getSetting } from '@/db/queries';
import { seedIfEmpty } from '@/db/seed';
import { detectLanguage, setLanguage, t, type LanguageCode } from '@/i18n';
import { useTheme } from '@/theme';

export default function RootLayout() {
  const theme = useTheme();
  const { success, error } = useMigrations(db, migrations);
  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);

  useEffect(() => {
    if (!success) return;
    (async () => {
      try {
        await seedIfEmpty();
        const saved = (await getSetting('language')) as LanguageCode | null;
        setLanguage(saved ?? detectLanguage());
        setReady(true);
      } catch (e) {
        setBootError(e instanceof Error ? e.message : String(e));
      }
    })();
  }, [success]);

  if (error || bootError) {
    return (
      <View style={[styles.center, { backgroundColor: theme.bg }]}>
        <Text style={[styles.errorTitle, { color: theme.danger }]}>
          Could not open the database
        </Text>
        <Text style={[styles.errorBody, { color: theme.textDim }]}>
          {error?.message ?? bootError}
        </Text>
      </View>
    );
  }

  if (!success || !ready) {
    return (
      <View style={[styles.center, { backgroundColor: theme.bg }]}>
        <ActivityIndicator color={theme.accent} />
        <Text style={[styles.errorBody, { color: theme.textDim }]}>{t('common.loading')}</Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="txn/[id]" options={{ presentation: 'card' }} />
        <Stack.Screen name="accounts" />
        <Stack.Screen name="categories" />
        <Stack.Screen name="reports" />
      </Stack>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, gap: 12 },
  errorTitle: { fontSize: 17, fontWeight: '600', textAlign: 'center' },
  errorBody: { fontSize: 14, textAlign: 'center' },
});

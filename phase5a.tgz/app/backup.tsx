import Constants from 'expo-constants';
import { useCallback, useState } from 'react';
import { ActivityIndicator, Alert, StyleSheet, Text, View } from 'react-native';

import {
  buildBackup,
  countAllRows,
  exportTransactionsCsv,
  importTransactionsCsv,
  restoreBackup,
} from '@/db/backup';
import { t } from '@/i18n';
import { pickTextFile, shareText, suggestedName } from '@/services/files';
import { space, type, useTheme } from '@/theme';
import { Button, Card, Screen, SectionLabel } from '@/ui';

/**
 * Your data, in your hands.
 *
 * Two different jobs, deliberately kept apart: CSV is for reading your spending
 * in a spreadsheet, and the backup file is for moving everything to a new phone.
 * Mixing them up is how people lose data — a CSV cannot restore your budgets,
 * your rules or your categories, and a backup file is unreadable in Excel.
 */
export default function BackupScreen() {
  const theme = useTheme();
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const appVersion = Constants.expoConfig?.version ?? '0.1.0';

  const run = useCallback(async (job: string, fn: () => Promise<string | null>) => {
    setBusy(job);
    setMessage(null);
    try {
      setMessage(await fn());
    } catch (e) {
      setMessage(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }, []);

  const exportCsv = useCallback(
    () =>
      run('csv', async () => {
        const csv = await exportTransactionsCsv(t);
        const res = await shareText(suggestedName('expenses', 'csv'), csv, 'text/csv');
        return res.ok ? t('backup.csvShared') : t('backup.shareFailed');
      }),
    [run],
  );

  const exportBackup = useCallback(
    () =>
      run('backup', async () => {
        const json = await buildBackup(appVersion);
        const res = await shareText(
          suggestedName('expense-backup', 'json'),
          json,
          'application/json',
        );
        return res.ok ? t('backup.backupShared') : t('backup.shareFailed');
      }),
    [run, appVersion],
  );

  const importCsv = useCallback(
    () =>
      run('importCsv', async () => {
        const text = await pickTextFile();
        if (text == null) return null;
        const res = await importTransactionsCsv(text, t);
        return t('backup.imported', { imported: res.imported, skipped: res.skipped });
      }),
    [run],
  );

  const doRestore = useCallback(async () => {
    const text = await pickTextFile(['application/json', '*/*']);
    if (text == null) return;

    const existing = await countAllRows();
    Alert.alert(t('backup.restoreTitle'), t('backup.restoreBody', { rows: existing }), [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('backup.restoreConfirm'),
        style: 'destructive',
        onPress: () =>
          run('restore', async () => {
            const res = await restoreBackup(text);
            if (!res.ok) return t(`backup.error.${res.error ?? 'notOurs'}`);
            const total = Object.values(res.counts ?? {}).reduce((a, b) => a + b, 0);
            return t('backup.restored', { rows: total });
          }),
      },
    ]);
  }, [run]);

  return (
    <Screen title={t('more.backup')} back>
      <Card>
        <SectionLabel>{t('backup.spreadsheet')}</SectionLabel>
        <Text style={[styles.body, { color: theme.textDim }]}>{t('backup.csvHint')}</Text>
        <Button label={t('backup.exportCsv')} onPress={exportCsv} disabled={busy !== null} />
        <Button
          label={t('backup.importCsv')}
          variant="secondary"
          onPress={importCsv}
          disabled={busy !== null}
        />
      </Card>

      <Card>
        <SectionLabel>{t('backup.newPhone')}</SectionLabel>
        <Text style={[styles.body, { color: theme.textDim }]}>{t('backup.backupHint')}</Text>
        <Button label={t('backup.exportBackup')} onPress={exportBackup} disabled={busy !== null} />
        <Button
          label={t('backup.restore')}
          variant="secondary"
          onPress={doRestore}
          disabled={busy !== null}
        />
        <Text style={[styles.warn, { color: theme.warn }]}>{t('backup.restoreWarning')}</Text>
      </Card>

      {busy ? (
        <View style={styles.busy}>
          <ActivityIndicator color={theme.accent} />
          <Text style={[styles.body, { color: theme.textDim }]}>{t('backup.working')}</Text>
        </View>
      ) : null}

      {message ? (
        <Card>
          <Text style={{ color: theme.text, fontSize: type.body }}>{message}</Text>
        </Card>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  body: { fontSize: type.small, lineHeight: 19 },
  warn: { fontSize: type.small, lineHeight: 19 },
  busy: { flexDirection: 'row', alignItems: 'center', gap: space.md, justifyContent: 'center' },
});

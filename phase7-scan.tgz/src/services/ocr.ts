/**
 * Reading text off a photo, on the device.
 *
 * Google's ML Kit, running entirely offline: no upload, no API key, no per-scan
 * cost, and it works on a train with no signal. The picture never leaves the
 * phone — which is the only reason photographing a receipt is an acceptable
 * thing to ask of someone.
 *
 * The module is loaded lazily and behind a try/catch. It is a native module, so
 * a JS-only reload after `npm install` will not have it, and a scan feature
 * that crashes the app on a stale build is worse than one that says "rebuild
 * the app" and carries on.
 */

export type OcrScript = 'latin' | 'devanagari';

export interface OcrResult {
  text: string;
  lines: string[];
}

/** Null when the native module is not in this build. */
function loadModule(): {
  recognize: (uri: string, script?: string) => Promise<{ text: string }>;
  scripts: Record<string, string>;
} | null {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const mod = require('@react-native-ml-kit/text-recognition');
    const api = mod?.default ?? mod;
    if (!api?.recognize) return null;
    return {
      recognize: api.recognize.bind(api),
      scripts: mod?.TextRecognitionScript ?? { LATIN: 'Latin', DEVANAGARI: 'Devanagari' },
    };
  } catch {
    return null;
  }
}

export function isOcrAvailable(): boolean {
  return loadModule() !== null;
}

/**
 * Read a receipt.
 *
 * Latin first, because even a Hindi shop prints its numbers in Latin digits
 * and Latin is the faster model. If that comes back with almost nothing, the
 * receipt is probably Devanagari, so try again — one wasted pass on a rare
 * receipt beats never reading it at all.
 */
export async function readImage(uri: string): Promise<OcrResult> {
  const mod = loadModule();
  if (!mod) throw new Error('ocrUnavailable');

  const latin = await mod.recognize(uri, mod.scripts.LATIN ?? 'Latin');
  let text = latin?.text ?? '';

  if (text.replace(/\s/g, '').length < 20) {
    try {
      const deva = await mod.recognize(uri, mod.scripts.DEVANAGARI ?? 'Devanagari');
      if ((deva?.text ?? '').length > text.length) text = deva.text;
    } catch {
      // Devanagari model missing or failed — keep whatever Latin found.
    }
  }

  return {
    text,
    lines: text
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l.length > 0),
  };
}

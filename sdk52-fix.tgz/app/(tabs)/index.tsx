import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  countInbox,
  getBaseCurrency,
  getFirstDayOfMonth,
  getMonthlyBudget,
  listCategories,
  listRecent,
  spentInPeriod,
} from '@/db/queries';
import type { Category, Transaction } from '@/db/schema';
import { computePace, monthBounds, type BudgetPace } from '@/domain/budget';
import { relativeDayKey } from '@/domain/dates';
import { formatMinor } from '@/domain/money';
import { formatDate, t } from '@/i18n';
import { radius, space, type, useTheme } from '@/theme';
import { EmptyState, ListRow, RowGroup, SectionLabel } from '@/ui';

/**
 * Home answers exactly one question, in one glance:
 *   "How much can I still spend this month?"
 * Everything else on this screen is supporting evidence.
 */
export default function HomeScreen() {
  const theme = useTheme();
  const router = useRouter();

  const [currency, setCurrency] = useState('INR');
  const [spent, setSpent] = useState(0);
  const [pace, setPace] = useState<BudgetPace | null>(null);
  const [recent, setRecent] = useState<Transaction[]>([]);
  const [categoryById, setCategoryById] = useState<Record<string, Category>>({});
  const [inbox, setInbox] = useState(0);

  const load = useCallback(async () => {
    const base = await getBaseCurrency();
    const firstDay = await getFirstDayOfMonth();
    const bounds = monthBounds(Date.now(), firstDay);
    const spentMinor = await spentInPeriod(bounds.start, bounds.end);
    const limit = await getMonthlyBudget();

    const map: Record<string, Category> = {};
    for (const c of [...(await listCategories('expense')), ...(await listCategories('income'))]) {
      map[c.id] = c;
    }

    setCurrency(base);
    setSpent(spentMinor);
    setPace(limit != null ? computePace(spentMinor, limit, Date.now(), bounds) : null);
    setCategoryById(map);
    setRecent(await listRecent(8));
    setInbox(await countInbox());
  }, []);

  // Reload whenever the tab comes back into view, so a new expense shows up.
  useFocusEffect(
    useCallback(() => {
      load();
    }, [load]),
  );

  const statusColor =
    pace?.status === 'over' ? theme.danger : pace?.status === 'warn' ? theme.warn : theme.accent;

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.bg }]} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content}>
        {/* Waiting for a tap ---------------------------------------------- */}
        {inbox > 0 ? (
          <Pressable
            onPress={() => router.push('/inbox')}
            style={({ pressed }) => [
              styles.inbox,
              {
                backgroundColor: pressed ? theme.accentSoft : theme.surface,
                borderColor: theme.accent,
              },
            ]}
          >
            <Text style={styles.inboxIcon}>📥</Text>
            <Text style={[styles.inboxText, { color: theme.text }]}>
              {t('inbox.waiting', { count: inbox })}
            </Text>
            <Text style={{ color: theme.accent, fontSize: 18 }}>›</Text>
          </Pressable>
        ) : null}

        {/* The number ----------------------------------------------------- */}
        <View style={[styles.hero, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <Text style={[styles.heroLabel, { color: theme.textDim }]}>
            {pace ? t('home.remaining') : t('home.noBudget')}
          </Text>

          <Text
            style={[styles.heroValue, { color: statusColor }]}
            numberOfLines={1}
            adjustsFontSizeToFit
          >
            {pace
              ? formatMinor(Math.max(pace.remainingMinor, 0), currency, { compact: true })
              : formatMinor(spent, currency, { compact: true })}
          </Text>

          {pace ? (
            <>
              <View style={[styles.track, { backgroundColor: theme.surfaceAlt }]}>
                <View
                  style={[
                    styles.fill,
                    {
                      backgroundColor: statusColor,
                      width: `${Math.min(100, Math.max(0, pace.fractionSpent * 100))}%`,
                    },
                  ]}
                />
                {/* Where the calendar says you should be. */}
                <View
                  style={[
                    styles.marker,
                    {
                      left: `${Math.min(100, pace.fractionElapsed * 100)}%`,
                      backgroundColor: theme.text,
                    },
                  ]}
                />
              </View>

              <Text style={[styles.heroMeta, { color: theme.textDim }]}>
                {pace.remainingMinor < 0
                  ? t('home.overBudget', {
                      amount: formatMinor(Math.abs(pace.remainingMinor), currency, { compact: true }),
                    })
                  : t('home.perDay', {
                      amount: formatMinor(pace.dailyAllowanceMinor, currency, { compact: true }),
                    })}
                {'  ·  '}
                {pace.daysRemaining === 1
                  ? t('home.dayLeft')
                  : t('home.daysLeft', { days: pace.daysRemaining })}
              </Text>

              <Text style={[styles.heroStatus, { color: statusColor }]}>
                {pace.status === 'warn'
                  ? t('home.paceWarn')
                  : pace.status === 'ok'
                    ? t('home.paceOk')
                    : ''}
              </Text>
            </>
          ) : (
            <Text
              style={[styles.heroMeta, { color: theme.accent }]}
              onPress={() => router.push('/budget')}
            >
              {t('home.setBudget')}
            </Text>
          )}
        </View>

        {/* Recent --------------------------------------------------------- */}
        <SectionLabel>{t('home.recent')}</SectionLabel>

        {recent.length === 0 ? (
          <EmptyState text={t('home.empty')} />
        ) : (
          <RowGroup>
            {recent.map((tx, i) => {
              const cat = tx.categoryId ? categoryById[tx.categoryId] : null;
              const catName = cat ? (cat.customName ?? t(cat.nameKey ?? '')) : null;
              const dayKey = relativeDayKey(tx.occurredAt);
              return (
                <ListRow
                  key={tx.id}
                  icon={cat?.icon ?? '•'}
                  title={tx.merchant || catName || t('add.expense')}
                  subtitle={dayKey ? t(dayKey) : formatDate(tx.occurredAt)}
                  value={formatMinor(tx.amountMinor, tx.currency, { compact: true, signed: true })}
                  valueColor={tx.amountMinor >= 0 ? theme.income : theme.text}
                  onPress={() => router.push(`/txn/${tx.id}`)}
                  last={i === recent.length - 1}
                />
              );
            })}
          </RowGroup>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  content: { padding: space.lg, gap: space.lg },
  inbox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: space.lg,
    paddingVertical: space.md,
  },
  inboxIcon: { fontSize: 20 },
  inboxText: { flex: 1, fontSize: type.small, fontWeight: '600' },
  hero: {
    borderRadius: radius.lg,
    borderWidth: 1,
    padding: space.xl,
    alignItems: 'center',
    gap: space.sm,
  },
  heroLabel: { fontSize: type.small, letterSpacing: 0.4, textTransform: 'uppercase' },
  heroValue: { fontSize: type.display, fontWeight: '700', letterSpacing: -1 },
  heroMeta: { fontSize: type.small, textAlign: 'center' },
  heroStatus: { fontSize: type.small, fontWeight: '600' },
  track: {
    width: '100%',
    height: 8,
    borderRadius: radius.pill,
    overflow: 'hidden',
    marginTop: space.sm,
    position: 'relative',
  },
  fill: { height: '100%', borderRadius: radius.pill },
  marker: { position: 'absolute', top: 0, bottom: 0, width: 2, opacity: 0.5 },
});

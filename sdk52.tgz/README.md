# Daily Expense Tracker

A free, offline-first Android expense tracker. All data lives on the phone.

- **Package id:** `com.mma.expensetracker` (permanent once published — do not change it)
- **Platform:** Android only · **Expo SDK 52** (matching your other projects)
- **Plan:** [`docs/PLAN.md`](docs/PLAN.md)
- **Phase:** 4a of 7 complete — rules, repeats and the inbox (no native modules yet)

---

## Getting it running on Windows

You need **Node 24**, **JDK 17**, and **Android Studio** (for the SDK and an emulator or ADB).

```powershell
npm install
npx expo install --fix      # aligns every expo-* package to SDK 52
npm test                    # 127 tests, should all pass
npm run typecheck           # should print nothing
npx expo prebuild --platform android
npx expo run:android        # builds and installs on a connected device
```

`npm install`, `npm test` and `npm run typecheck` have been run against this
exact `package.json` and source, so if any of them fails it is your environment
(Node version, npm cache, corporate proxy), not the code — say so and it can be
fixed.

**Two things to know about staying on SDK 52.**

1. **Google Play needs target API 36 for new apps** (since 31 Aug 2026). SDK 52
   prebuilds with `targetSdkVersion 34` / `compileSdkVersion 35`, so a Play
   submission would be rejected as-is. It does not affect building, installing
   on your own phone, or Indus Appstore. When Play submission gets close, either
   move to a newer SDK or override the levels with `expo-build-properties`
   (untested against RN 0.76 — try it before relying on it).
2. **The New Architecture is off** on SDK 52 (`newArchEnabled=false`). Nothing in
   the app needs it today. It matters only if a future dependency requires it —
   FlashList v2 is the one on our roadmap that does.

**One warning you can ignore.** `npm ls` reports `react-native-worklets@0.12.1`
as an invalid peer of `expo-modules-core`. That is a stale *optional* peer range
inside Expo SDK 57 itself: `react-native-reanimated@4.6.0` requires `0.12.x` and
that is what gets installed, which is correct. Install succeeds; nothing to fix.

Once `prebuild` has generated the `android/` folder, later builds can skip it:

```powershell
npm run build:apk           # android\app\build\outputs\apk\release\app-release.apk
npm run build:aab           # the bundle Google Play wants
```

### Four Windows problems worth heading off

These cause most first-build failures on Windows, and none of them are your fault.

1. **Enable long paths.** Gradle and `node_modules` blow past the 260-character limit constantly.
   ```powershell
   # Run as Administrator, then restart:
   New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" `
     -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force
   ```
2. **Do not move this project into OneDrive.** It breaks Metro and Gradle reliably. `C:\Najmus\` is fine.
3. **Pin JDK 17 explicitly.** Set `JAVA_HOME` yourself rather than relying on whatever Android Studio bundles.
4. **Exclude the project from Windows Defender** (`node_modules` and `android\build` especially), or builds take two to three times longer. The first New Architecture C++ compile can take 15–40 minutes; add this to `android/gradle.properties` after prebuild:
   ```properties
   org.gradle.jvmargs=-Xmx4096m
   org.gradle.daemon=true
   org.gradle.caching=true
   ```

### Signing — do this before you ship anything

```powershell
keytool -genkeypair -v -keystore expense-tracker.keystore -alias expense `
  -keyalg RSA -keysize 2048 -validity 10000
```

Put the passwords in `%USERPROFILE%\.gradle\gradle.properties`, **never in this repo** (`.gitignore` already blocks `*.keystore`).

**Back the keystore up to two places today.** If you lose it, you can never publish an update to the same app again.

---

## Layout

```
app/                    Screens. expo-router turns this folder into navigation.
  (tabs)/
    index.tsx           Home — "how much can I still spend this month?"
    add.tsx             The keypad. The most important screen in the app.
    history.tsx         The month's ledger, grouped by day, searchable
    budget.tsx          Monthly budget, overall and per category, with pace
    more.tsx            Settings, and the way into everything below
  txn/[id].tsx          Edit or delete one transaction
  accounts.tsx          Cash, bank, cards, UPI — each with its own currency
  categories.tsx        Add your own, hide the ones you don't use
  reports.tsx           Where it went, day by day, month on month
  rules.tsx             "Anything from SWIGGY is Food"
  recurring.tsx         Rent, EMIs, subscriptions
  inbox.tsx             Captured automatically, waiting for one tap

src/
  db/
    schema.ts           ONE definition of every table (also used by the server in v1.1)
    client.ts           Opens the database
    seed.ts             Default categories and account on first run
    queries.ts          Every read and write the screens use
  domain/               PURE functions — no React, no database. This is where the tests are.
    money.ts            Integer minor units. Never a float.
    budget.ts           Month bounds and budget pace
    merchant.ts         Turns bank descriptors into a stable merchant key
    dates.ts            Calendar maths — month grids, relative days, DST-safe
    report.ts           Ranking, folding the tail, series buckets, change %
    rules.ts            Rule matching, first-match-wins, safe regex
    recurrence.ts       An RRULE subset — parse, next occurrence, catch-up
  i18n/                 English and Hindi, no library
  theme/                Colours, spacing, type scale
  ui/                   Shared components — Screen, Card, ListRow, Chip, Sheet
    charts.tsx          Ranked bars and columns, drawn with plain Views

drizzle/                Generated SQL migrations — commit these
docs/PLAN.md            The full product and technical plan
```

### Five rules the code enforces

1. **Money is an integer number of paise.** Never a float, never a `REAL` column. `0.1 + 0.2` is exactly how expense trackers end up a rupee off.
2. **Every row carries `id`, `updated_at`, `deleted_at`, `dirty`.** Sync ships in v1.1; having these now means switching it on is additive rather than a migration.
3. **Nothing is hard-deleted.** `deleted_at` is set instead.
4. **IDs are UUIDs generated on the phone.** No server round-trip to save a row.
5. **Nothing the app records for you is written silently.** Anything captured automatically lands in the inbox for one tap. That rule is the whole basis for trusting an app that types on your behalf.

---

## Changing the database

```powershell
# 1. edit src/db/schema.ts
npm run db:generate      # writes a new migration into drizzle/
# 2. commit both the schema change and the generated files
```

Migrations run automatically on app start (`app/_layout.tsx`).

---

## Tests

```powershell
npm test
```

Covers the domain layer only — money arithmetic, budget pacing, merchant normalization, calendar maths, report aggregation, rule matching and recurrence. That is deliberate: these are the places where a bug costs a user real trust, and they are pure functions, so the tests are fast and there is no transform pipeline to break. Screen tests can come later; they are worth far less than these.

---

## Two deliberate deviations from the plan

Both exist to keep the Windows build simple. Both are easy to change later, and neither affects the data model.

- **Plain `StyleSheet` instead of NativeWind.** Every colour and size is already a token in `src/theme`, so moving to NativeWind is mechanical rather than a rewrite.
- **Charts drawn with plain Views, not a charting library.** Both questions the app answers are about magnitude, which reads best from a common baseline — so ranked bars and columns, single-series, every row labelled. No SVG, no categorical palette, and therefore no colour-blindness problem to mitigate.
- **A 40-line `t()` instead of i18next.** Two languages with simple interpolation is all this needs, and it removes a dependency whose version has to stay aligned with the Expo SDK. If pluralization gets complicated, i18next can replace it without touching a single call site.

---

## What is not here yet

Receipt scanning, SMS capture, rules, recurring transactions, charts, the widget, backup/export, and the sync server. See `docs/PLAN.md` §8 for the order they arrive in.

Phase 4b is next, and it is the first phase that adds native modules: receipt scanning (camera + on-device ML Kit), local reminder notifications, and the home-screen widget. Those need a working Gradle build to be worth writing, so they wait for your first green build.

**Privacy, from the first commit:** nothing leaves the phone. No analytics, no accounts, no network calls at all.
